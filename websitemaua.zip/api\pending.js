// api/pending.js
// Endpoint danh rieng cho Plugin Minecraft goi dinh ky de lay cac don hang can phat do
import { getOrders } from "./storage.js";

const DEFAULT_SECRET = "maua_minecraft_key_2026";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();

  const secret = req.query.secret || req.headers["x-plugin-secret"];
  const expectedSecret = process.env.PLUGIN_API_KEY || DEFAULT_SECRET;

  if (secret !== expectedSecret) {
    return res.status(401).json({ success: false, error: "Sai ma khoa bi mat (API Secret Key)!" });
  }

  try {
    const orders = await getOrders();
    // Lay cac don da duyet (approved) dang cho Minecraft server thuc hien
    const approvedOrders = orders.filter(o => o.status === "approved");

    return res.status(200).json({
      success: true,
      count: approvedOrders.length,
      orders: approvedOrders
    });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
}
