// api/storage.js
// He thong luu tru thong minh: ho tro Vercel KV / Upstash Redis hoac bo nho Memory

const DEFAULT_ITEMS = [
  {
    id: "item_tanthu",
    name: "Hộp Quà Tân Thủ",
    category: "free",
    price: 0,
    icon: "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/1.20.4/assets/minecraft/textures/item/golden_apple.png",
    description: "Bộ quà chào đón người chơi mới: 16 Táo vàng, 1 Khiên, 64 Bánh mì",
    commands: [
      "give {player} golden_apple 16",
      "give {player} shield 1",
      "give {player} bread 64"
    ]
  },
  {
    id: "item_kiemthan",
    name: "Kiếm Thần Netherite",
    category: "weapons",
    price: 20000,
    icon: "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/1.20.4/assets/minecraft/textures/item/netherite_sword.png",
    description: "Vũ khí huyền thoại: Sắc bén V (Sharpness V), Nhặt đồ III (Looting III)",
    commands: [
      "give {player} netherite_sword[enchantments={levels:{sharpness:5,looting:3,unbreaking:3}}] 1"
    ]
  },
  {
    id: "item_giapvip",
    name: "Áo Giáp Kim Cương VIP",
    category: "armor",
    price: 25000,
    icon: "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/1.20.4/assets/minecraft/textures/item/diamond_chestplate.png",
    description: "Bảo vệ tối đa: Bảo vệ IV (Protection IV), Bền bỉ III (Unbreaking III)",
    commands: [
      "give {player} diamond_chestplate[enchantments={levels:{protection:4,unbreaking:3}}] 1"
    ]
  },
  {
    id: "item_kc64",
    name: "64 Khối Kim Cương",
    category: "resources",
    price: 10000,
    icon: "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/1.20.4/assets/minecraft/textures/block/diamond_block.png",
    description: "Tài nguyên dồi dào: 64 Khối kim cương nguyên chất",
    commands: [
      "give {player} diamond_block 64"
    ]
  },
  {
    id: "item_fly",
    name: "Quyền Lệnh Bay (/fly)",
    category: "ranks",
    price: 50000,
    icon: "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/1.20.4/assets/minecraft/textures/item/feather.png",
    description: "Thoải mái bay lượn ngắm nhìn công trình trong server",
    commands: [
      "lp user {player} permission set essentials.fly true",
      "fly {player} on"
    ]
  },
  {
    id: "item_coin",
    name: "100,000 Xu Server",
    category: "money",
    price: 15000,
    icon: "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/1.20.4/assets/minecraft/textures/item/gold_ingot.png",
    description: "Cộng ngay 100,000 tiền tệ vào tài khoản trong game",
    commands: [
      "eco give {player} 100000"
    ]
  }
];

// Memory store to maintain state across lambdas if KV is not yet connected
let memoryItems = [...DEFAULT_ITEMS];
let memoryOrders = [];

// Helper check Redis KV
function getKvConfig() {
  const url = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
  if (url && token) {
    return { url, token };
  }
  return null;
}

async function kvGet(key) {
  const cfg = getKvConfig();
  if (!cfg) return null;
  try {
    const res = await fetch(`${cfg.url}/get/${key}`, {
      headers: { Authorization: `Bearer ${cfg.token}` }
    });
    const data = await res.json();
    if (data.result) {
      return JSON.parse(data.result);
    }
  } catch (err) {
    console.error("KV get error:", err);
  }
  return null;
}

async function kvSet(key, value) {
  const cfg = getKvConfig();
  if (!cfg) return false;
  try {
    const payload = JSON.stringify(value);
    await fetch(`${cfg.url}/set/${key}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${cfg.token}`,
        "Content-Type": "application/json"
      },
      body: payload
    });
    return true;
  } catch (err) {
    console.error("KV set error:", err);
  }
  return false;
}

// Exported database functions
export async function getItems() {
  const kvItems = await kvGet("shop_items");
  if (kvItems && Array.isArray(kvItems) && kvItems.length > 0) {
    return kvItems;
  }
  return memoryItems;
}

export async function saveItems(items) {
  memoryItems = items;
  await kvSet("shop_items", items);
  return items;
}

export async function getOrders() {
  const kvOrders = await kvGet("shop_orders");
  if (kvOrders && Array.isArray(kvOrders)) {
    return kvOrders;
  }
  return memoryOrders;
}

export async function saveOrders(orders) {
  memoryOrders = orders;
  await kvSet("shop_orders", orders);
  return orders;
}

export async function addOrder(order) {
  const orders = await getOrders();
  orders.unshift(order); // Newest first
  await saveOrders(orders);
  return order;
}

export async function getPendingOrders() {
  const orders = await getOrders();
  return orders.filter(o => o.status === "pending" || o.status === "approved");
}

export async function markOrderCompleted(orderId) {
  const orders = await getOrders();
  const order = orders.find(o => o.id === orderId);
  if (order) {
    order.status = "completed";
    order.completedAt = new Date().toISOString();
    await saveOrders(orders);
    return true;
  }
  return false;
}
