// api/admin.js
import { getOrders, saveOrders, getItems, saveItems } from "./storage.js";

const DEFAULT_ADMIN_PASS = "admin123";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();

  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed" });
  }

  const { password, action, payload } = req.body || {};
  const expectedPass = process.env.ADMIN_PASSWORD || DEFAULT_ADMIN_PASS;

  if (password !== expectedPass) {
    return res.status(401).json({ success: false, error: "Sai mật khẩu Admin!" });
  }

  try {
    if (action === "login") {
      return res.status(200).json({ success: true, message: "Đăng nhập thành công!" });
    }

    if (action === "get_data") {
      const orders = await getOrders();
      const items = await getItems();
      return res.status(200).json({ success: true, orders, items });
    }

    if (action === "approve_order") {
      const { orderId } = payload || {};
      const orders = await getOrders();
      const order = orders.find(o => o.id === orderId);
      if (order) {
        order.status = "approved";
        await saveOrders(orders);
        return res.status(200).json({ success: true, message: "Đã duyệt đơn thành công!" });
      }
      return res.status(404).json({ success: false, error: "Không tìm thấy đơn hàng" });
    }

    if (action === "delete_order") {
      const { orderId } = payload || {};
      let orders = await getOrders();
      orders = orders.filter(o => o.id !== orderId);
      await saveOrders(orders);
      return res.status(200).json({ success: true, message: "Đã xóa đơn hàng!" });
    }

    if (action === "add_item") {
      const { item } = payload || {};
      if (!item || !item.name || !item.commands) {
        return res.status(400).json({ success: false, error: "Thiếu thông tin vật phẩm!" });
      }
      item.id = "item_" + Date.now();
      const items = await getItems();
      items.push(item);
      await saveItems(items);
      return res.status(200).json({ success: true, message: "Đã thêm vật phẩm mới!", item });
    }

    if (action === "delete_item") {
      const { itemId } = payload || {};
      let items = await getItems();
      items = items.filter(i => i.id !== itemId);
      await saveItems(items);
      return res.status(200).json({ success: true, message: "Đã xóa vật phẩm!" });
    }

    return res.status(400).json({ success: false, error: "Action không hợp lệ!" });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
}
